# 05 网站部署指南：从零到上线（GitHub Pages + Cloudflare）

前提：你已拥有 `ccwu.cc` 主域名，且该域名的DNS已托管在Cloudflare（即Cloudflare是这个域名的Nameserver）。目标：让 `xyong.ccwu.cc` 指向本方案包 `website/` 目录中的静态网站。

---

## 第一步：创建 GitHub 仓库并上传网站代码

1. 登录/注册 GitHub 账号（https://github.com）。
2. 右上角 `+` → **New repository**。
3. 仓库名建议填 `xyong-yunnan-website`（名称任意，不影响自定义域名绑定），设为 **Public**（GitHub Pages免费版要求公开仓库，除非你有GitHub Pro/企业版）。
4. 创建完成后，把本方案包中的 `website/` 目录**整个文件夹的内容**（不是外层website文件夹本身，是里面的index.html等文件）上传到该仓库根目录。两种方式任选：
   - **网页端拖拽上传**：打开仓库页面 → `Add file` → `Upload files` → 把 `website/` 里所有文件和子文件夹拖进去 → 填写提交信息 → `Commit changes`。
   - **命令行方式**（如果你本地装了git）：
     ```bash
     cd website
     git init
     git add .
     git commit -m "初始化网站"
     git branch -M main
     git remote add origin https://github.com/你的用户名/xyong-yunnan-website.git
     git push -u origin main
     ```
5. 确认仓库根目录能看到：`index.html`、`products.html`、`batches.html`、`science.html`、`about.html`、`contact.html`、`CNAME`、`assets/`、`data/` 这些文件/文件夹。

## 第二步：开启 GitHub Pages

1. 进入仓库 → 顶部 `Settings` → 左侧菜单 `Pages`。
2. **Source** 选择 `Deploy from a branch`。
3. **Branch** 选择 `main`，目录选择 `/ (root)`，点击 `Save`。
4. 稍等1–2分钟，页面顶部会出现绿色提示 "Your site is live at https://你的用户名.github.io/xyong-yunnan-website/"，先点开确认能正常访问（此时还是github.io的默认地址，还没绑定你的自定义域名）。

## 第三步：在 GitHub Pages 设置自定义域名

1. 仍在 `Settings → Pages` 页面，找到 **Custom domain** 输入框，填入 `xyong.ccwu.cc`，点击 `Save`。
   - 因为你的 `website/CNAME` 文件里已经写好了 `xyong.ccwu.cc`，这一步GitHub会自动识别，如果没自动填入你就手动填一次再Save。
2. 此时GitHub会提示"域名尚未正确解析"，这是正常的，因为我们还没去Cloudflare配置DNS，继续下一步。

## 第四步：在 Cloudflare 添加 DNS 记录

1. 登录 Cloudflare 控制台（https://dash.cloudflare.com），选中 `ccwu.cc` 这个域名。
2. 左侧菜单进入 **DNS → Records**。
3. 点击 **Add record**，按下面填写：
   - **Type**: `CNAME`
   - **Name**: `xyong`
   - **Target**: `你的用户名.github.io`（注意末尾不要带具体仓库名路径，只到 `.github.io`）
   - **Proxy status**：**第一次先选 "DNS only"（灰色云朵）**，方便GitHub先完成域名所有权验证和证书签发，等第七步确认HTTPS生效后，你可以再改回"Proxied"（橙色云朵）享受Cloudflare的CDN加速和防护。
   - **TTL**: Auto
4. 点击 **Save**。

> 说明：因为 `xyong` 是子域名（不是裸域根域名 `ccwu.cc` 本身），用 **CNAME 记录**指向 `用户名.github.io` 即可，不需要像根域名那样配置4条A记录指向GitHub的IP地址。

## 第五步：回到 GitHub 确认域名验证通过

1. 回到 GitHub 仓库 `Settings → Pages`，刷新页面。
2. 等待几分钟（DNS生效通常几分钟到最多48小时，Cloudflare通常很快，一般10分钟内）。
3. 看到 **Custom domain** 下方出现绿色小勾提示 "DNS check successful"，说明解析已生效。
4. 勾选 **Enforce HTTPS**（强制HTTPS，此选项在DNS验证通过、GitHub自动签发Let's Encrypt证书后才会变为可勾选状态，可能需要再等几分钟到1小时）。

## 第六步：（可选但推荐）把 Cloudflare 代理重新打开

1. 回到 Cloudflare DNS 设置，把第四步添加的 `xyong` 记录的 Proxy status 从"DNS only"改为 **Proxied（橙色云朵）**。
2. 进入 Cloudflare 左侧菜单 **SSL/TLS → Overview**，把加密模式设置为 **Full**（不要选Flexible，否则可能出现重定向循环报错）。
3. 这样之后你就同时获得：GitHub Pages免费托管 + Cloudflare的CDN加速、防护、以及未来可能用到的Cloudflare Workers/D1等能力。

## 第七步：验证上线

1. 浏览器访问 `https://xyong.ccwu.cc`，应能看到网站首页正常展示，地址栏显示锁形图标（HTTPS生效）。
2. 依次点击各个导航（产品/批次查询/科普/关于/联系），确认页面都能正常打开，且"批次查询"页能正确读取并展示 `data/batches.json` 里的示例数据。
3. 用手机浏览器再测试一次，确认响应式布局正常。

## 第八步：后续更新数据/内容的日常操作

以后每次工厂产出新批次数据，更新网站的操作只需要：

1. 打开 `factory-data/` 里导出的最新批次JSON（或直接编辑 `website/data/batches.json`，把新批次对象加进数组）；
2. 在GitHub仓库网页端直接编辑该文件（进入文件 → 点右上角铅笔图标 → 粘贴/修改内容 → Commit changes），或本地改完后 `git add . && git commit -m "更新批次数据" && git push`；
3. 提交后1–2分钟内，`https://xyong.ccwu.cc/batches.html` 会自动展示最新数据，**不需要重新部署，不需要重启任何服务**，这就是纯静态架构的好处。

## 常见问题排查

| 问题 | 排查方向 |
|---|---|
| 提示"DNS check unsuccessful" | 检查CNAME记录Name是否填的是`xyong`而非`xyong.ccwu.cc`（Cloudflare会自动补全域名后缀）；确认Target没有多余的 `http://` 前缀或结尾斜杠 |
| 打开是空白页/404 | 确认仓库根目录直接就是index.html等文件，而不是嵌套在一个`website`子文件夹里 |
| HTTPS一直无法勾选强制 | 通常是证书还没签发完，等待30分钟到1小时；如果超过24小时仍不行，检查Cloudflare代理是否开启导致证书签发受阻，先切回DNS only模式 |
| 改了数据文件网站没更新 | 检查是否提交(commit)到了`main`分支；浏览器强制刷新(Ctrl+F5)清除缓存；Cloudflare若开启了缓存，可在Cloudflare后台 `Caching → Configuration → Purge Cache` 手动清缓存 |
