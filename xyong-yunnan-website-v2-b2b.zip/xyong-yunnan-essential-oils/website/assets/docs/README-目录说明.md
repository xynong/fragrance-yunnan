# assets/docs 目录说明

用于存放可下载的PDF文档，例如：

- `xyong-catalog.pdf` — 产品批发目录（英文Wholesale页"Download Catalog"按钮引用此文件）
- 未来可放置：公司简介PDF、COA示例PDF、SDS安全数据表模板等

制作方法：用Word/PPT/Canva做好PDF后，直接以对应文件名上传到本目录即可，网站按钮会自动生效。
