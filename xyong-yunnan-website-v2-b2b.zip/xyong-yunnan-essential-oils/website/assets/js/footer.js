// 统一页脚，避免每个页面重复维护同一份 HTML；自动识别中/英文目录
document.addEventListener('DOMContentLoaded', () => {
  const el = document.getElementById('site-footer');
  if (!el) return;
  const isEn = document.documentElement.lang && document.documentElement.lang.startsWith('en');

  const zh = {
    brand: '香芬云南 XYONG · YUNNAN',
    tagline: '云南本土芳香植物精油，水蒸气蒸馏工艺，批批GC检测数据公开。从山头到瓶子，透明可查。为跨境批发与私人定制（OEM/ODM）供应原料级与成品精油。',
    navTitle: '导航',
    nav: [['./products.html','产品'], ['./batches.html','批次查询'], ['./science.html','科普'], ['./about.html','关于我们']],
    bizTitle: '商务合作',
    biz: [['./contact.html','采购咨询 / 询盘'], ['./en/wholesale.html','B2B / 批发 (EN)']],
    contactTitle: '联系方式',
    contact: ['xyong.ccwu.cc', '出口贸易垂询：见"购买/联系"页'],
    bottomLeft: '香芬云南 XYONG · YUNNAN',
    bottomRight: '本站批次数据来自自建质控实验室及第三方检测机构'
  };
  const en = {
    brand: 'XYONG · YUNNAN',
    tagline: 'Yunnan-grown aromatic plants, steam-distilled, batch-by-batch GC-tested and published. From mountain to bottle — fully traceable. Wholesale, private label (OEM/ODM) and bulk raw-material supply for international buyers.',
    navTitle: 'Explore',
    nav: [['./products.html','Products'], ['./quality.html','Quality & COA'], ['./about.html','About']],
    bizTitle: 'For Buyers',
    biz: [['./wholesale.html','Wholesale / B2B'], ['./request-quote.html','Request a Quote']],
    contactTitle: 'Contact',
    contact: ['xyong.ccwu.cc/en', 'Export enquiries via "Request a Quote"'],
    bottomLeft: 'XYONG · YUNNAN Essential Oils',
    bottomRight: 'Batch data sourced from in-house QC lab and third-party laboratories'
  };
  const t = isEn ? en : zh;

  el.innerHTML = `
    <div class="container">
      <div class="footer-grid">
        <div>
          <h4>${t.brand}</h4>
          <p style="max-width:38ch; color:rgba(246,243,236,0.7); font-size:13px;">${t.tagline}</p>
        </div>
        <div>
          <h4>${t.navTitle}</h4>
          <ul>${t.nav.map(([href,label]) => `<li><a href="${href}">${label}</a></li>`).join('')}</ul>
        </div>
        <div>
          <h4>${t.bizTitle}</h4>
          <ul>${t.biz.map(([href,label]) => `<li><a href="${href}">${label}</a></li>`).join('')}</ul>
        </div>
        <div>
          <h4>${t.contactTitle}</h4>
          <ul>${t.contact.map(c => `<li>${c}</li>`).join('')}</ul>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© <span id="footer-year"></span> ${t.bottomLeft}</span>
        <span>${t.bottomRight}</span>
      </div>
    </div>
  `;
  const y = document.getElementById('footer-year');
  if (y) y.textContent = new Date().getFullYear();
});
