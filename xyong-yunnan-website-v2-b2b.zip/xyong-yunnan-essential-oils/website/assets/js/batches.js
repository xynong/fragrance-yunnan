// ============================================================
// 批次查询 / Quality & COA 页：渲染全部批次数据 + 按植物筛选 + GC成分区间可视化
// 自动识别中/英文目录，切换字段与相对路径
// ============================================================

let ALL_BATCHES = [];
let ACTIVE_FILTER = 'all';

document.addEventListener('DOMContentLoaded', async () => {
  const grid = document.getElementById('batch-grid');
  const toolbar = document.getElementById('batch-toolbar');
  if (!grid) return;

  const base = (typeof DATA_BASE !== 'undefined') ? DATA_BASE : './data/';

  try {
    const res = await fetch(base + 'batches.json');
    ALL_BATCHES = await res.json();

    buildToolbar(toolbar);
    renderBatches(grid);

    const params = new URLSearchParams(location.search);
    const target = params.get('batch');
    if (target) {
      setTimeout(() => {
        const card = document.querySelector(`[data-batch-id="${CSS.escape(target)}"]`);
        if (card) {
          card.scrollIntoView({ behavior: 'smooth', block: 'center' });
          card.style.outline = '2px solid var(--clay)';
        }
      }, 100);
    }
  } catch (e) {
    grid.innerHTML = `<p class="text-mist">${(typeof LANG !== 'undefined' && LANG === 'en') ? 'Failed to load batch data. Please retry shortly.' : '批次数据加载失败，请稍后重试。'}</p>`;
    console.error(e);
  }
});

function tPlant(b) {
  return (typeof LANG !== 'undefined' && LANG === 'en') ? (b.plant_en || b.plant) : b.plant;
}

function buildToolbar(toolbar) {
  if (!toolbar) return;
  const isEn = (typeof LANG !== 'undefined' && LANG === 'en');
  const plants = ['all', ...new Set(ALL_BATCHES.map(b => b.plant))];
  toolbar.innerHTML = plants.map(p => {
    const label = p === 'all' ? (isEn ? 'All Batches' : '全部批次') : (isEn ? (ALL_BATCHES.find(b => b.plant === p)?.plant_en || p) : p);
    return `<button class="filter-btn ${p === 'all' ? 'active' : ''}" data-plant="${p}">${label}</button>`;
  }).join('');

  toolbar.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      toolbar.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      ACTIVE_FILTER = btn.dataset.plant;
      renderBatches(document.getElementById('batch-grid'));
    });
  });
}

function renderBatches(grid) {
  const list = ACTIVE_FILTER === 'all'
    ? ALL_BATCHES
    : ALL_BATCHES.filter(b => b.plant === ACTIVE_FILTER);

  const sorted = [...list].sort((a, b) => new Date(b.distill_date) - new Date(a.distill_date));
  const isEn = (typeof LANG !== 'undefined' && LANG === 'en');

  if (sorted.length === 0) {
    grid.innerHTML = `<p class="text-mist">${isEn ? 'No batches for this plant yet.' : '暂无该植物批次数据。'}</p>`;
    return;
  }

  grid.innerHTML = sorted.map(renderBatchCard).join('');
}

function markerPercentOfRange(marker) {
  const match = marker.spec_range.match(/([\d.]+)\s*-\s*([\d.]+)/);
  if (!match) return 50;
  const lo = parseFloat(match[1]);
  const hi = parseFloat(match[2]);
  const span = hi - lo || 1;
  const pos = ((marker.percent - lo) / span) * 100;
  return Math.max(4, Math.min(100, pos));
}

function renderBatchCard(b) {
  const isEn = (typeof LANG !== 'undefined' && LANG === 'en');
  const isPass = b.release_status === '合格放行';
  const t = isEn
    ? { origin: 'Origin', harvest: 'Harvest / Distill', process: 'Process', yieldKg: 'Input / Output', yieldPct: 'Yield', physical: 'Physical', notes: 'Notes', foot: 'GC-tested · every batch', report: 'Download COA (PDF)', reportPending: 'COA pending upload' }
    : { origin: '产地', harvest: '采摘 / 蒸馏', process: '工艺', yieldKg: '投料量 / 产出', yieldPct: '出油率', physical: '理化指标', notes: '备注', foot: 'GC定量放行 · 每批必测', report: '检测报告 PDF', reportPending: '检测报告待上传' };

  const markersHtml = (b.gc_markers || []).map(m => `
    <div class="marker">
      <div class="marker-label">
        <span class="name">${isEn ? (m.compound_en || m.compound) : m.compound}</span>
        <span class="val">${m.percent}%</span>
      </div>
      <div class="marker-bar"><i style="width:${markerPercentOfRange(m)}%"></i></div>
      <div class="marker-range">${isEn ? 'Spec range' : '标准区间'} ${m.spec_range}${isEn ? '' : `（基线 ${b.spec_baseline_version}）`}</div>
    </div>
  `).join('');

  return `
  <div class="batch-card" data-batch-id="${b.batch_id}">
    <div class="specimen-head">
      <div>
        <div class="specimen-id mono">${b.batch_id}</div>
        <h3>${tPlant(b)}</h3>
      </div>
      <span class="status-pill ${isPass ? '' : 'warn'}">${isEn ? (b.release_status_en || b.release_status) : b.release_status}</span>
    </div>
    <div class="specimen-body">
      <div class="meta-row"><span>${t.origin}</span><b>${isEn ? (b.origin_town_en || b.origin_town) : b.origin_town}</b></div>
      <div class="meta-row"><span>${t.harvest}</span><b>${b.harvest_date} / ${b.distill_date}</b></div>
      <div class="meta-row"><span>${t.process}</span><b>${isEn ? (b.process_en || b.process) : b.process}</b></div>
      <div class="meta-row"><span>${t.yieldKg}</span><b>${b.input_kg}kg → ${b.output_ml}ml</b></div>
      <div class="meta-row"><span>${t.yieldPct}</span><b>${(b.yield_percent * 100).toFixed(2)}%</b></div>
      ${markersHtml}
      <div class="meta-row"><span>${t.physical}</span><b>${isEn ? 'Density' : '密度'} ${b.physical?.density_20c ?? '-'} · ${isEn ? 'RI' : '折光率'} ${b.physical?.refractive_index ?? '-'} · ${isEn ? 'OR' : '旋光度'} ${b.physical?.optical_rotation ?? '-'}</b></div>
      ${b.notes ? `<div class="meta-row"><span>${t.notes}</span><b>${isEn ? (b.notes_en || b.notes) : b.notes}</b></div>` : ''}
    </div>
    <div class="specimen-foot">
      <span>${t.foot}</span>
      ${b.test_report_url ? `<a class="link-batch" href="${b.test_report_url}" target="_blank" rel="noopener">${t.report}</a>` : `<span>${t.reportPending}</span>`}
    </div>
  </div>`;
}
