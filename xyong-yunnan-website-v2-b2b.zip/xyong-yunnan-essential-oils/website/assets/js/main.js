// ============================================================
// 通用交互：移动端导航 / 页脚年份 / 首页信任模块 / 产品列表渲染
// 纯前端 fetch 本地 JSON，无需任何后端服务
// 自动识别中文根目录 / 英文 /en/ 子目录，切换数据字段与相对路径
// ============================================================

const LANG = document.documentElement.lang && document.documentElement.lang.startsWith('en') ? 'en' : 'zh';
const DATA_BASE = LANG === 'en' ? '../data/' : './data/';

document.addEventListener('DOMContentLoaded', () => {
  initNav();
  setFooterYear();
  highlightActiveNav();
  initMediaSlots();
  initFaqAccordions();

  if (document.getElementById('home-latest-batches')) {
    renderHomeLatestBatches();
  }
  if (document.getElementById('product-grid')) {
    renderProductGrid();
  }
});

function initNav() {
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (!toggle || !links) return;
  toggle.addEventListener('click', () => links.classList.toggle('open'));
}

function setFooterYear() {
  const el = document.getElementById('footer-year');
  if (el) el.textContent = new Date().getFullYear();
}

function highlightActiveNav() {
  const path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    const href = a.getAttribute('href');
    if (href && href.split('/').pop() === path) a.classList.add('active');
  });
}

// ---------- 媒体占位符：图片/视频加载失败时优雅降级为设计感占位符 ----------
// 用法：<div class="media-slot ratio-16-9"><img src="../assets/img/xxx.jpg" alt="">
//        <div class="media-placeholder">...</div></div>
// 图片文件不存在时自动加上 is-empty class，显示占位符提示（含建议尺寸文案）
function initMediaSlots() {
  document.querySelectorAll('.media-slot').forEach(slot => {
    const media = slot.querySelector('img, video');
    if (!media) { slot.classList.add('is-empty'); return; }
    if (media.tagName === 'IMG') {
      media.addEventListener('error', () => slot.classList.add('is-empty'));
      if (media.complete && media.naturalWidth === 0) slot.classList.add('is-empty');
    } else if (media.tagName === 'VIDEO') {
      media.addEventListener('error', () => slot.classList.add('is-empty'));
      media.addEventListener('loadeddata', () => slot.classList.remove('is-empty'));
    }
  });
}

// ---------- FAQ 手风琴 ----------
function initFaqAccordions() {
  document.querySelectorAll('.faq-q').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.closest('.faq-item').classList.toggle('open');
    });
  });
}

async function loadJSON(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error('无法加载数据: ' + path);
  return res.json();
}

// ---------- 首页：最新批次信任模块 ----------
async function renderHomeLatestBatches() {
  const el = document.getElementById('home-latest-batches');
  const t = LANG === 'en'
    ? { origin: 'Origin', distill: 'Distilled', yield: 'Yield', more: 'Full COA data', link: 'View Batch' }
    : { origin: '产地', distill: '蒸馏日期', yield: '出油率', more: '查看完整检测数据', link: '批次查询' };
  try {
    const batches = await loadJSON(DATA_BASE + 'batches.json');
    const latest = [...batches]
      .sort((a, b) => new Date(b.distill_date) - new Date(a.distill_date))
      .slice(0, 3);

    el.innerHTML = latest.map(b => `
      <div class="batch-card">
        <div class="specimen-head">
          <div>
            <div class="specimen-id mono">${b.batch_id}</div>
            <h3>${LANG === 'en' ? (b.plant_en || b.plant) : b.plant}</h3>
          </div>
          <span class="status-pill">${LANG === 'en' ? (b.release_status_en || b.release_status) : b.release_status}</span>
        </div>
        <div class="specimen-body">
          <div class="meta-row"><span>${t.origin}</span><b>${LANG === 'en' ? (b.origin_town_en || b.origin_town) : b.origin_town}</b></div>
          <div class="meta-row"><span>${t.distill}</span><b>${b.distill_date}</b></div>
          <div class="meta-row"><span>${t.yield}</span><b>${(b.yield_percent * 100).toFixed(2)}%</b></div>
        </div>
        <div class="specimen-foot">
          <span>${t.more} →</span>
          <a href="${LANG === 'en' ? './quality.html' : './batches.html'}" class="link-batch">${t.link}</a>
        </div>
      </div>
    `).join('');
  } catch (e) {
    el.innerHTML = `<p class="text-mist">${LANG === 'en' ? 'Loading batch data…' : '批次数据加载中，请稍后刷新。'}</p>`;
    console.error(e);
  }
}

// ---------- 产品页：渲染5款产品卡片 ----------
async function renderProductGrid() {
  const el = document.getElementById('product-grid');
  try {
    const [products, batches] = await Promise.all([
      loadJSON(DATA_BASE + 'products.json'),
      loadJSON(DATA_BASE + 'batches.json'),
    ]);

    el.innerHTML = products.map(p => {
      const batch = batches.find(b => b.batch_id === p.latest_batch_id);
      const name = LANG === 'en' ? p.name_en : p.name_cn;
      const subtitle = LANG === 'en' ? p.name_cn : p.name_en;
      const origin = LANG === 'en' ? (p.plant_origin_en || p.plant_origin) : p.plant_origin;
      const process = LANG === 'en' ? (p.process_en || p.process) : p.process;
      const desc = LANG === 'en' ? (p.description_en || p.description) : p.description;
      const tags = LANG === 'en' ? (p.emotion_tags_en || p.emotion_tags) : p.emotion_tags;
      const moq = LANG === 'en' ? (p.moq_en || '') : (p.moq_cn || '');
      const linkTxt = LANG === 'en'
        ? (batch ? 'View Batch COA' : 'View Batch')
        : (batch ? '查看本批次检测数据' : '查看批次');
      const batchPage = LANG === 'en' ? './quality.html' : './batches.html';
      return `
      <div class="product-card">
        <div class="swatch accent-${p.accent}">
          <div class="swatch-icon">${plantIcon(p.id)}</div>
        </div>
        <div class="product-body">
          <div class="origin mono">${origin} · ${process}</div>
          <h3>${name}</h3>
          <div class="en">${subtitle}</div>
          <p>${desc}</p>
          <div class="emotion-tags">
            ${tags.map(t => `<span>${t}</span>`).join('')}
          </div>
          ${moq ? `<span class="product-moq">${moq}</span>` : ''}
          <div class="product-foot">
            <span class="spec-list">${p.spec_options.join(' / ')}</span>
            <a class="link-batch" href="${batchPage}?batch=${encodeURIComponent(p.latest_batch_id)}">
              ${linkTxt} →
            </a>
          </div>
        </div>
      </div>`;
    }).join('');
  } catch (e) {
    el.innerHTML = `<p class="text-mist">${LANG === 'en' ? 'Loading products…' : '产品数据加载中，请稍后刷新。'}</p>`;
    console.error(e);
  }
}

// ---------- 原创植物线条图标（SVG inline，避免使用第三方图片） ----------
function plantIcon(id) {
  const icons = {
    'rose-otto': '<svg viewBox="0 0 48 48" fill="none" stroke-width="1.6"><circle cx="24" cy="20" r="9"/><path d="M24 29v14M24 33c-4 0-7 3-9 6M24 33c4 0 7 3 9 6"/><circle cx="24" cy="20" r="3.4"/></svg>',
    'peppermint': '<svg viewBox="0 0 48 48" fill="none" stroke-width="1.6"><path d="M24 44V14"/><path d="M24 18c-6 0-10-4-10-9 5 0 9 3 10 8"/><path d="M24 24c6 0 10-4 10-9-5 0-9 3-10 8"/><path d="M24 30c-6 0-10-4-10-9 5 0 9 3 10 8"/></svg>',
    'lemongrass': '<svg viewBox="0 0 48 48" fill="none" stroke-width="1.6"><path d="M18 44 22 12"/><path d="M24 44 24 10"/><path d="M30 44 26 12"/></svg>',
    'pine-needle': '<svg viewBox="0 0 48 48" fill="none" stroke-width="1.6"><path d="M24 44V10"/><path d="M24 16 14 22M24 16 34 22"/><path d="M24 24 14 30M24 24 34 30"/><path d="M24 32 16 37M24 32 32 37"/></svg>',
    'rosemary': '<svg viewBox="0 0 48 48" fill="none" stroke-width="1.6"><path d="M24 44V12"/><path d="M24 16 18 13M24 20 30 17M24 24 18 21M24 28 30 25M24 32 18 29M24 36 30 33"/></svg>'
  };
  return icons[id] || '<svg viewBox="0 0 48 48" fill="none" stroke-width="1.6"><circle cx="24" cy="24" r="10"/></svg>';
}
